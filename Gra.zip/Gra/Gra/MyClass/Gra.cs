﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gra.MyClass
{
    internal class Gra
    {
        public Postac Postac1 { get; set; }
        public Postac Postac2 { get; set; }
        public Gra()
        {
            char plec = 'M';
            Random rnd= new Random();
            int random = rnd.Next(0, 1);
            if (random == 1)
            {
                plec = 'M';
                
            }    
            else if(random == 0)
            {
                plec = 'K';
            }
            Postac1 = new Postac("Gerard", plec, 100, 0);


        }
    }
}
