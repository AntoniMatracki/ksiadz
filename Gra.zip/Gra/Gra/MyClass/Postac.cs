﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gra.MyClass
{
    internal class Postac
    {
        public string nazwa { get; set; }
        public char plec { get; set; }
        public int poziom { get; set; }
        public int PD { get; set; } 
        public Ekwipunek GraczEkwipunek { get; set; }

        public Postac(string nazwa, char plec, int poziom, int PD)
        { 
        this.nazwa = nazwa;
        this.plec = plec;
        this.poziom = poziom;
        this.PD = PD;
        this.GraczEkwipunek = new Ekwipunek("Patyk", "Skórzana");
        }
        public void ZmeinPoziom(int PD)
        {
            this.PD += PD;
            if (this.PD == 100) 
            {
                this.PD = 0;    
                this.PD++;
            }
        }
        public override string ToString()
        {
            return nazwa + " " + GraczEkwipunek;
        }

        public class Ekwipunek
        {
            public string Miecz;
            public string Zbroja;
        
        public Ekwipunek(string Miecz, string Zbroja)
        {
            this.Miecz = Miecz;
            this.Zbroja = Zbroja;
        }

            public void PoprawEkwipunek(int level)
            {
                switch (level) 
                {
                    case <= 10: break;
                    case <= 15:
                        this.Miecz = "Drewniany";
                        this.Zbroja = "Skórzana";
                        break;
                    case <= 20:
                        this.Miecz = "Stalowy";
                        this.Zbroja = "Kolczuga";
                        break;
                    case <= 30:
                        this.Miecz = "Obsydianowy";
                        this.Zbroja = "Stalowa";
                        break;
                    case <= 40:
                        this.Miecz = "Diamentowy";
                        this.Zbroja = "Diamentowa";
                        break;
                }
            }

        }

    }
}
